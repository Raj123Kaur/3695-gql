module.exports = [
    {
        id: '1',
        name: "Raj",
        email: "raj123@gmail.com",
        phone: '7783627978',
        relationship: 'Friend',
        address: [{
            id: '101',
            address1: "Drake street, 101A",
            address2: "Unit 139",
            pcode: "V2B1A7",
            city: "Vancouver",
            province: "BC",
            country: "Canada"}]
    },
    {
        id: '2',
        name: "Vanshi",
        email: "vanshi123@gmail.com",
        phone: '7783627977',
        relationship: 'Work',
        address: [{
                id: '102',
                address1: "Cambie street, 201A",
                address2: "Apt 301",
                pcode: "V4B1C7",
                city: "Vancouver",
                province: "BC",
                country: "Canada"
        }]    
    },

    {
        id: '3',
        name: "Kevin",
        email: "vanshi123@gmail.com",
        phone: '7783627997',
        relationship: 'Work',
        address: [{
            id: '103',
            address1: "120 street, 72A",
            address2: "UNIT A",
            pcode: "V2B1A7",
            city: "Delta",
            province: "BC",
            country: "Canada"
        }]
    }
]