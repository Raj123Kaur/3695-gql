const { ApolloServer, gql } = require('apollo-server')
const mongoose = require('mongoose');
const contacts = require('./contact')
const addresses = require('./address')

const Contact = mongoose.model("Contact", {
  id: String,
  name: String,
  email: String,
  phone: String,
  relationship: String
});

const typeDefs = gql`

 enum Relationship {
    Friend
    Family
    Work
    Other
  }

  type Contact {
    id: ID!
    name: String
    email: String
    phone: String
    address: [Address]
    relationship: Relationship
  }

  type Address {
      id: ID!
      address1: String
      address2: String
      pcode: String
      city: String
      province: String
      country: String
  }
  
  type Query {
    contacts: [Contact]
    addresses: [Address]
    contactsByName(name: String!): Contact
  }

  type Mutation {
    createContact(id: ID!, name:String!, email:String!, phone: String!): Contact,
    updateContact(id: ID!, name:String!, email:String!, phone: String!): Contact
  }
  `


const resolvers = {
  Query: {
    contacts: () => contacts,
    addresses: () => addresses,
    contactsByName: (_, { name }) => {
      const contactsList = contacts.find(b => b.name == name)
      return contactsList
    }
  },

  Mutation: {
    createContact: async (_, { id, name, email, phone}) => {
      const contact = new Contact({ id, name, email, phone});
      await contact.save();
      return contact;
  }
  }
}


const server = new ApolloServer({ typeDefs, resolvers })

server.listen().then(({ url }) => {
  console.log(`🚀 Server ready at ${url}`);
});